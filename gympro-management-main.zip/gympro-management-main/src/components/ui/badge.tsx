import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
  {
    variants: {
      variant: {
        default: 'border-transparent bg-primary/90 text-primary-foreground hover:brightness-105',
        secondary: 'border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/60',
        destructive: 'border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/85',
        outline: 'text-foreground hover:bg-muted/30',
        brand: 'border-transparent bg-brand-gradient text-white shadow-sm hover:brightness-110',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  }
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
